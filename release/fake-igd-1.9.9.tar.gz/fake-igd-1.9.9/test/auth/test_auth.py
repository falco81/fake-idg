#!/usr/bin/env python3
"""test_auth.py - the sign-ins, the accounts and root's boundary (1.9.9): what was found wrong and put right.

  python3 test/auth/test_auth.py         (from the source tree; nothing of the machine is touched - every
                                         path is a folder of its own under /tmp)

What it proves:

  - a database put back (Settings → Database, Backups) leaves who is signed in now as they are: the file's
    own sign-ins do not come back to life (one ended since - signed out, its password changed - opened the
    pages again for whoever still had its cookie)
  - a database of an older version put back gets this version's columns at once (signing in broke on "no
    such column" until the API was restarted), and a 1.9.2-1.9.6 one has its passkeys moved as on opening
  - the columns are added once however many open the database at the same moment (the API and upnp user)
  - Export and import: an account's password written over by the file ends its sign-ins; the last full
    admin who can sign in stays one, also for an import from the command line
  - root's helpers never write or read through a link the fake-igd account laid in its own folder: the
    stop of a system update (osup.stop), the network's trial (net-trial.json), the queue of asks (web/ask)
"""
import importlib.util
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
SRC = os.path.join(ROOT, "src")
DEPLOY = os.path.join(ROOT, "deploy")
sys.path[:0] = [SRC]
TMP = tempfile.mkdtemp(prefix="fake-igd-auth-test-")
os.environ["FAKE_IGD_SEAL_KEY"] = os.path.join(TMP, "secrets.key")

import igd_store as ST      # noqa: E402
import igd_panes as PN      # noqa: E402

PN.load()
DB = sys.modules["api_db"]
CARRY = sys.modules["api_carry"]

# The tables of 1.4.0, before any column was added (igd_store.COLUMNS) and before passkeys' questions.
OLD_SCHEMA = """
CREATE TABLE users (name TEXT PRIMARY KEY COLLATE NOCASE, role TEXT NOT NULL, hash TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '', must_change INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL,
    changed REAL NOT NULL, last_login REAL, last_from TEXT);
CREATE TABLE sessions (id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE, created REAL NOT NULL,
    seen REAL NOT NULL, addr TEXT NOT NULL DEFAULT '', agent TEXT NOT NULL DEFAULT '');
CREATE TABLE fails (at REAL NOT NULL, addr TEXT NOT NULL, name TEXT NOT NULL COLLATE NOCASE);
CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL, kind TEXT NOT NULL,
    level TEXT NOT NULL DEFAULT 'info', who TEXT NOT NULL DEFAULT '', addr TEXT NOT NULL DEFAULT '',
    words TEXT NOT NULL);
CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT);
"""


def module(name, path, env):
    """A file of deploy/ loaded afresh with its paths pointed into the test's folder."""
    old = {k: os.environ.get(k) for k in env}
    os.environ.update(env)
    try:
        spec = importlib.util.spec_from_file_location(name + "_t%d" % time.monotonic_ns(), path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


class Base(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp(dir=TMP)
        self.S = ST.Store(os.path.join(self.dir, "fake-igd.db"))
        self.S.add_user("admin", "secret123", "fulladmin")
        self.S.add_user("viewer", "secret123", "readonly")

    def tearDown(self):
        self.S.close()

    def ctx(self, me="admin"):
        u = {"name": me, "role": "fulladmin"}
        return PN.Ctx(None, "POST", "/api/x", {}, u, self.S, {"state_dir": self.dir}, DB, self.S.add_event)


class Restore(Base):
    def copy_now(self):
        p = os.path.join(self.dir, "copy.db")
        DB.snapshot(self.S, p)
        return p

    def test_ended_sign_ins_stay_ended(self):
        old, _u = self.S.login("viewer", "secret123", "192.0.2.9")
        copy = self.copy_now()
        self.S.logout(old)                                   # ended after the copy was made
        mine, _u = self.S.login("admin", "secret123", "192.0.2.1")
        self.assertIsNone(self.S.session(old))
        DB.restore_from(self.ctx(), copy, "a copy")
        self.assertIsNone(self.S.session(old), "a sign-in ended before the restore came back with the file")
        self.assertEqual(self.S.session(mine)["name"], "admin", "the one who put it back was signed out")

    def test_old_version_gets_its_columns(self):
        p = os.path.join(self.dir, "old.db")
        db = sqlite3.connect(p)
        db.executescript(OLD_SCHEMA)
        now = time.time()
        db.execute("INSERT INTO users VALUES ('old', 'fulladmin', ?, '', 0, ?, ?, NULL, NULL)",
                   (ST.hash_password("secret456"), now, now))
        db.execute("INSERT INTO events (at, kind, words) VALUES (?, 'x', 'y')", (now,))
        db.commit()
        db.close()
        DB.restore_from(self.ctx(), p, "an old copy")
        tok, u = self.S.login("old", "secret456", "192.0.2.1")
        self.assertEqual(self.S.session(tok)["name"], "old")
        self.assertEqual(self.S.users()[0]["passkeys"], 0)
        self.S.challenge_put("192.0.2.1", {"challenge": "c" * 43})

    def test_passkeys_of_1_9_6_moved(self):
        key = {"id": "k1", "alg": -7, "pub": "x", "host": "h"}
        self.S.run("UPDATE users SET mfa = ? WHERE name = 'admin'", (json.dumps({"kind": "passkey", "keys": [key]}),))
        copy = self.copy_now()
        self.S.run("UPDATE users SET mfa = '' WHERE name = 'admin'")
        DB.restore_from(self.ctx(), copy, "a copy of 1.9.6")
        self.assertEqual(self.S.mfa_get("admin"), {})
        self.assertEqual([k["id"] for k in self.S.passkeys("admin")], ["k1"])


class RestoreCrafted(Base):
    """A file put back is fake-igd's tables and nothing more, of a sane size, its manifest naming its own files."""

    def test_triggers_and_views_dropped(self):
        p = os.path.join(self.dir, "crafted.db")
        DB.snapshot(self.S, p)
        db = sqlite3.connect(p)
        db.execute("CREATE TRIGGER up AFTER INSERT ON sessions BEGIN UPDATE users SET role = 'fulladmin'; END")
        db.execute("CREATE VIEW peek AS SELECT name, hash FROM users")
        db.commit()
        db.close()
        got = DB.restore_from(self.ctx(), p, "a crafted copy")
        self.assertIn("trigger up", got["key"])
        left = self.S.rows("SELECT name FROM sqlite_master WHERE type IN ('trigger', 'view')")
        self.assertEqual(left, [], "the file's trigger and view stayed in the database")
        self.S.login("viewer", "secret123")
        self.assertEqual(self.S.user("viewer")["role"], "readonly")

    def test_gzip_bomb_refused(self):
        import gzip
        p = os.path.join(self.dir, "bomb.db.gz")
        with gzip.open(p, "wb") as f:
            f.write(b"SQLite format 3\x00")
            for _ in range(40):
                f.write(b"\x00" * (1 << 20))
        was = DB.DB_MOST
        DB.DB_MOST = 8 << 20
        try:
            with self.assertRaises(ValueError) as e:
                DB.unpack(p, os.path.join(self.dir, "out.db"))
        finally:
            DB.DB_MOST = was
        self.assertIn("refused", str(e.exception))
        self.assertFalse(os.path.exists(os.path.join(self.dir, "out.db")))

    def backup_file(self, files, manifest=None):
        import io
        import tarfile
        top = "fake-igd-backup-lab-node-20261120-000000"
        p = os.path.join(self.dir, "b-%d.tar.gz" % time.monotonic_ns())
        with tarfile.open(p, "w:gz") as tf:
            for name, data in list(files.items()) + [("manifest.json", json.dumps(manifest or {"files": {}}).encode())]:
                ti = tarfile.TarInfo("%s/%s" % (top, name))
                ti.size = len(data)
                tf.addfile(ti, io.BytesIO(data))
        return p

    def open_it(self, p):
        BK = sys.modules["api_backup"]
        work = tempfile.mkdtemp(dir=self.dir)
        return BK.open_file(None, p, "", work)

    def test_backup_member_too_big(self):
        BK = sys.modules["api_backup"]
        was = BK.OPEN_MOST_OTHER
        BK.OPEN_MOST_OTHER = 1024
        try:
            with self.assertRaises(BK.RbError) as e:
                self.open_it(self.backup_file({"config.json": b" " * 4096}))
        finally:
            BK.OPEN_MOST_OTHER = was
        self.assertIn("refused", str(e.exception))
        with self.assertRaises(BK.RbError):
            self.open_it(self.backup_file({"x%d" % i: b"" for i in range(BK.OPEN_MOST_FILES + 1)}))

    def test_manifest_names_checked(self):
        BK = sys.modules["api_backup"]
        import hashlib
        with open(self.victim_file(), "rb") as f:
            sha = hashlib.sha256(f.read()).hexdigest()
        for rel in (self.victim_file(), "../../../../" + self.victim_file().lstrip("/"), "a/../../x", ""):
            with self.assertRaises(BK.RbError) as e:
                self.open_it(self.backup_file({"config.json": b"{}"}, {"files": {rel: {"sha256": sha}}}))
            self.assertIn("does not belong there", str(e.exception))
        good = {"config.json": {"sha256": hashlib.sha256(b"{}").hexdigest()}}
        m, _x = self.open_it(self.backup_file({"config.json": b"{}"}, {"files": good}))
        self.assertIn("config.json", m["files"])

    def victim_file(self):
        p = os.path.join(self.dir, "victim")
        if not os.path.exists(p):
            with open(p, "w") as f:
                f.write("a file of this machine\n")
        return p


class ServerMoved(Base):
    """A token or password goes only to the server it was typed for: the server changed, it is typed again."""

    def setUp(self):
        Base.setUp(self)
        import fake_igd_api as A
        self.A = A
        cfg = os.path.join(self.dir, "config.json")
        with open(cfg, "w") as f:
            json.dump({"state_dir": self.dir, "ntfy_url": "https://ntfy.example.com/ps5", "ntfy_token": "tk_kept_one"}, f)
        A.CFG_PATH = cfg
        A.STORE[0] = self.S
        A.load_cfg(force=True)
        A.settings_save({"smtp_host": "mail.example.com", "smtp_password": "kept-mail-pw",
                         "proxy_url": "http://proxy.example.com:3128", "proxy_password": "kept-proxy-pw"}, "admin", "?")

    def save(self, changes):
        return self.A.settings_save(dict(changes), "admin", "?")

    def test_mikrotik_unit(self):
        # 1.9.9: the MikroTik's password stays with the router it was typed for
        import igd_panes as P
        now = {"mikrotik_host": "192.0.2.1", "mikrotik_password": "kept"}.get
        self.assertEqual([x[0] for x in P.secrets_left_behind({"mikrotik_host": "192.0.2.99"}, now)], ["mikrotik_password"])
        self.assertEqual(P.secrets_left_behind({"mikrotik_host": "192.0.2.99", "mikrotik_password": "typed"}, now), [])
        self.assertEqual(P.secrets_left_behind({"mikrotik_host": "192.0.2.1"}, now), [])

    def test_ntfy(self):
        with self.assertRaises(ValueError) as e:
            self.save({"ntfy_url": "https://evil.example.net/ps5", "ntfy_token": "•" * 8 + "ne"})
        self.assertIn("ntfy access token again", str(e.exception))
        with self.assertRaises(ValueError):
            self.save({"ntfy_url": "http://ntfy.example.com/ps5"})            # https -> http: another server too
        self.assertEqual(self.A.load_cfg(force=True)["ntfy_url"], "https://ntfy.example.com/ps5")
        self.save({"ntfy_url": "https://ntfy.example.com/other-topic", "ntfy_token": "•" * 8 + "ne"})
        self.save({"ntfy_url": "https://NTFY.example.com:443/ps5"})
        self.save({"ntfy_url": ""})                                            # switched off: sent nowhere
        self.save({"ntfy_url": "https://new.example.org/ps5", "ntfy_token": "tk_typed_again"})
        self.assertEqual(self.A.load_cfg(force=True)["ntfy_token"], "tk_typed_again")

    def test_mail_and_proxy(self):
        with self.assertRaises(ValueError) as e:
            self.save({"smtp_host": "smtp.evil.example.net", "smtp_password": "•" * 8 + "pw"})
        self.assertIn("mail server's password", str(e.exception))
        with self.assertRaises(ValueError) as e:
            self.save({"proxy_url": "http://evil.example.net:3128"})
        self.assertIn("proxy's password", str(e.exception))
        self.save({"smtp_host": "MAIL.example.com", "smtp_port": 587})
        self.save({"proxy_url": "http://proxy.example.com:3128/"})
        self.save({"smtp_host": "smtp.new.example.org", "smtp_password": "a-new-one"})
        self.save({"proxy_url": "http://other.example.org:8080", "proxy_password": ""})
        self.assertEqual(PN.value(self.S, "smtp_password"), "a-new-one")

    def test_import_takes_the_kept_one_away(self):
        main = sys.modules["__main__"]
        main.settings_save, main.load_cfg = self.A.settings_save, self.A.load_cfg
        try:
            got = CARRY.import_conf(self.ctx(), {"config": {"ntfy_url": "https://elsewhere.example.org/t"},
                                                 "settings": {"smtp_host": "smtp.elsewhere.example.org"}}, False)
        finally:
            del main.settings_save, main.load_cfg
        self.assertEqual(self.A.load_cfg(force=True)["ntfy_token"], "")
        self.assertEqual(PN.value(self.S, "smtp_password"), "")
        self.assertEqual(len(got["cleared"]), 2)

    def test_command_line(self):
        import argparse
        import upnp as U
        cfg = self.A.CFG_PATH
        args = argparse.Namespace(config=cfg, config_cmd="set", key="ntfy_url", value="https://ntfy.example.com/x",
                                  no_restart=True, json=False)
        U.cmd_config(args, {})
        with open(cfg) as f:
            self.assertEqual(json.load(f)["ntfy_token"], "tk_kept_one")
        args.value = "https://other.example.org/x"
        U.cmd_config(args, {})
        with open(cfg) as f:
            got = json.load(f)
        self.assertEqual((got["ntfy_url"], got["ntfy_token"]), ("https://other.example.org/x", ""))


class Migrate(unittest.TestCase):
    def test_twice_and_at_the_same_moment(self):
        d = tempfile.mkdtemp(dir=TMP)
        p = os.path.join(d, "old.db")
        db = sqlite3.connect(p)
        db.executescript(OLD_SCHEMA)
        db.close()
        a = ST.Store(p)
        a.migrate()
        a.migrate()

        class Late(object):
            """The connection of one that read the columns before the other added them."""
            def __init__(self, db):
                self._db = db

            def execute(self, sql, *args):
                if sql.startswith("PRAGMA table_info"):
                    return self._db.execute("SELECT 1 WHERE 0")
                return self._db.execute(sql, *args)

            def __getattr__(self, k):
                return getattr(self._db, k)
        b = ST.Store(p)
        b.db = Late(b.db)
        b.migrate()                                      # "duplicate column name" is no error here
        cols = [r[1] for r in a.db.execute("PRAGMA table_info(users)").fetchall()]
        self.assertEqual(cols.count("passkeys"), 1)
        a.close()
        b.db._db.close()


class Import(Base):
    def test_new_hash_ends_sign_ins(self):
        tok, _u = self.S.login("viewer", "secret123", "192.0.2.9")
        rows = [{"name": "viewer", "role": "readonly", "hash": ST.hash_password("another99")}]
        CARRY.import_users(self.ctx(), rows, False, "admin")
        self.assertIsNone(self.S.session(tok), "a sign-in with the password written over stayed open")
        tok, _u = self.S.login("viewer", "another99", "192.0.2.9")
        rows = [{"name": "viewer", "role": "readonly", "note": "same password", "hash": self.S.user("viewer")["hash"]}]
        CARRY.import_users(self.ctx(), rows, False, "admin")
        self.assertIsNotNone(self.S.session(tok), "the same password ended the sign-in")

    def test_last_full_admin_stays(self):
        rows = [{"name": "admin", "role": "readonly", "hash": self.S.user("admin")["hash"]},
                {"name": "viewer", "role": "readonly"}]
        said, _made, _gone = CARRY.import_users(self.ctx("root (command line)"), rows, True, "root (command line)")
        self.assertEqual(self.S.user("admin")["role"], "fulladmin")
        self.assertTrue(any("stays a full admin" in s for s in said))
        self.S.add_user("second", "secret123", "fulladmin")
        rows = [{"name": "admin", "role": "readonly"}, {"name": "second", "role": "readonly"}]
        CARRY.import_users(self.ctx("root (command line)"), rows, False, "root (command line)")
        self.assertEqual(self.S.count_admins(), 1)


class Hdr(object):
    def __init__(self, token, body):
        self.headers = {"X-IGD-Session": token, "X-IGD-Host": "fakeigd.test", "User-Agent": "test"}
        self._b = body

    def addr(self):
        return "192.0.2.7"

    def body(self, most=0):
        return dict(self._b)


class PasskeyGone(Base):
    """A passkey taken away (a lost phone): the sign-ins it opened end with it."""

    def setUp(self):
        Base.setUp(self)
        self.S.passkeys_put("admin", [{"id": "phone", "alg": -7, "pub": "x", "host": "fakeigd.test", "count": 0},
                                      {"id": "laptop", "alg": -7, "pub": "y", "host": "fakeigd.test", "count": 0}])
        self.phone, _u = self.S.passkey_login("admin", dict(self.S.passkeys("admin")[0], count=1))
        self.laptop, _u = self.S.passkey_login("admin", dict(self.S.passkeys("admin")[1], count=1))
        self.pw, _u = self.S.login("admin", "secret123")

    def test_your_account_takes_one_away(self):
        AP = sys.modules["api_people"]
        me = self.S.session(self.laptop)
        ctx = PN.Ctx(Hdr(self.laptop, {"action": "delete", "id": "phone"}), "POST", "/api/passkeys", {}, me, self.S,
                     {}, AP, self.S.add_event)
        AP.pk_do(ctx)
        self.assertIsNone(self.S.session(self.phone), "the lost phone stayed signed in")
        self.assertIsNotNone(self.S.session(self.laptop))
        self.assertIsNotNone(self.S.session(self.pw))
        # Its own key taken away from the device it signed in with: this sign-in stays (it asked).
        ctx = PN.Ctx(Hdr(self.laptop, {"action": "delete", "id": "laptop"}), "POST", "/api/passkeys", {}, me, self.S,
                     {}, AP, self.S.add_event)
        AP.pk_do(ctx)
        self.assertIsNotNone(self.S.session(self.laptop))

    def test_accounts_take_every_one_away(self):
        self.assertEqual(self.S.passkeys_remove("admin"), 2)
        self.assertIsNone(self.S.session(self.phone))
        self.assertIsNone(self.S.session(self.laptop))
        self.assertIsNotNone(self.S.session(self.pw), "a sign-in with the password ended too")

    def test_sign_in_of_1_9_8_without_its_key(self):
        self.S.run("UPDATE sessions SET data = ? WHERE id = ?", (json.dumps({"by": "passkey"}), ST._sid(self.phone)))
        self.S.end_passkey_sessions("admin", "laptop")
        self.assertIsNone(self.S.session(self.phone))


class RootLinks(unittest.TestCase):
    """What the fake-igd account owns (/var/lib/fake-igd, its web/) may hold its links: root never follows one."""

    def setUp(self):
        self.dir = tempfile.mkdtemp(dir=TMP)
        self.state = os.path.join(self.dir, "state")
        os.makedirs(os.path.join(self.state, "web", "ask"))
        self.victim = os.path.join(self.dir, "victim")
        with open(self.victim, "w") as f:
            f.write("root's own\n")

    def test_osup_stop(self):
        lock = os.path.join(self.dir, "osup.lock")
        R = module("root_osup", os.path.join(DEPLOY, "root_osup.py"),
                   {"FAKE_IGD_STATE": self.state, "FAKE_IGD_OSUP_LOCK": lock})
        job = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)", "--job", "root_osup.py"])
        import fcntl
        fd = os.open(lock, os.O_RDWR | os.O_CREAT, 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            web = os.path.join(self.state, "web")
            with open(os.path.join(web, "osup.json"), "w") as f:
                json.dump({"state": "running", "phase": "asking for what is new", "pid": job.pid}, f)
            os.symlink(self.victim, os.path.join(web, "osup.stop"))
            R.stop("admin")
            job.wait(10)
        finally:
            os.close(fd)
            if job.poll() is None:
                job.kill()
        with open(self.victim) as f:
            self.assertEqual(f.read(), "root's own\n", "root wrote through the link")
        self.assertFalse(os.path.islink(os.path.join(self.state, "web", "osup.stop")))
        # osup.json as a link: not read through it either
        os.unlink(os.path.join(self.state, "web", "osup.json"))
        os.symlink(self.victim, os.path.join(self.state, "web", "osup.json"))
        with self.assertRaises(OSError):
            R.read_here("osup.json")

    def test_net_trial(self):
        other = os.path.join(self.dir, "elsewhere")
        os.makedirs(other)
        shutil.rmtree(os.path.join(self.state, "web"))
        os.symlink(other, os.path.join(self.state, "web"))
        R = module("root_net", os.path.join(DEPLOY, "root_net.py"), {"FAKE_IGD_STATE": self.state})
        R.trial_write({"state": "trial"})
        self.assertEqual(os.listdir(other), [], "root wrote into the folder the link pointed to")
        os.unlink(os.path.join(self.state, "web"))
        os.makedirs(os.path.join(self.state, "web"))
        R.trial_write({"state": "trial", "snapshot": "abcdef12"})
        self.assertEqual(R.trial_read()["snapshot"], "abcdef12")
        os.unlink(R.TRIAL_FILE)
        os.symlink(self.victim, R.TRIAL_FILE)
        self.assertEqual(R.trial_read(), {})

    def test_queue_through_a_link(self):
        other = os.path.join(self.dir, "elsewhere")
        os.makedirs(os.path.join(other, "ask"))
        with open(os.path.join(other, "ask", "keep-me"), "w") as f:
            f.write("x")
        shutil.rmtree(os.path.join(self.state, "web"))
        os.symlink(other, os.path.join(self.state, "web"))
        W = module("fake_igd_web", os.path.join(DEPLOY, "fake_igd_web.py"), {"FAKE_IGD_STATE": self.state})
        W.serve_queue()
        self.assertEqual(os.listdir(os.path.join(other, "ask")), ["keep-me"], "root took another folder's files")


if __name__ == "__main__":
    try:
        unittest.main(verbosity=1)
    finally:
        shutil.rmtree(TMP, ignore_errors=True)
