# This file is part of Pebble.
# Copyright (c) 2013-2026, Matteo Cafasso

# Pebble is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.

# Pebble is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Pebble.  If not, see <http://www.gnu.org/licenses/>.

from enum import Enum, IntEnum
from dataclasses import dataclass
from concurrent.futures import Future
from multiprocessing.connection import Connection
from multiprocessing.synchronize import RLock as RLockType
from typing import Any, ParamSpec, Generic, Protocol, Tuple, TypeVar


T = TypeVar("T")
P = ParamSpec("P")


class MultiprocessingContext(Protocol):
    """Structural type of the objects Pebble accepts as a multiprocessing context.

    Either the multiprocessing module itself (the default) or a
    multiprocessing.context.BaseContext instance returned by
    multiprocessing.get_context(), such as SpawnContext, ForkContext
    or ForkServerContext.

    Process is intentionally not declared here: each start-method context
    exposes it as a differently-typed ClassVar (e.g. SpawnContext.Process is
    type[SpawnProcess]), which pyright cannot match structurally against a
    single Protocol member. typeshed's own BaseContext omits it for the same
    reason.

    """

    def Pipe(self, duplex: bool = True) -> Tuple[Connection, Connection]: ...

    def RLock(self) -> RLockType: ...

    def get_start_method(self) -> str: ...


class ProcessExpired(OSError):
    """Raised when process dies unexpectedly."""

    def __init__(self, msg, code=0, pid=None):
        super(ProcessExpired, self).__init__(msg)
        self.exitcode = code
        self.pid = pid


class ProcessFuture(Future[T]):
    # Same as base class, removed logline
    def set_running_or_notify_cancel(self):
        """Mark the future as running or process any cancel notifications.

        Should only be used by Executor implementations and unit tests.

        If the future has been cancelled (cancel() was called and returned
        True) then any threads waiting on the future completing (though calls
        to as_completed() or wait()) are notified and False is returned.

        If the future was not cancelled then it is put in the running state
        (future calls to running() will return True) and True is returned.

        This method should be called by Executor implementations before
        executing the work associated with this future. If this method returns
        False then the work should not be executed.

        Returns:
            False if the Future was cancelled, True otherwise.

        Raises:
            RuntimeError: if set_result() or set_exception() was called.
        """
        with self._condition:
            if self._state == FutureStatus.CANCELLED:
                self._state = FutureStatus.CANCELLED_AND_NOTIFIED
                for waiter in self._waiters:
                    waiter.add_cancelled(self)

                return False
            elif self._state == FutureStatus.PENDING:
                self._state = FutureStatus.RUNNING

                return True
            else:
                raise RuntimeError("Future in unexpected state")

    def cancel(self):
        """Cancel the future.

        Returns True if the future was cancelled, False otherwise. A future
        cannot be cancelled if it has already completed.
        """
        with self._condition:
            if self._state == FutureStatus.FINISHED:
                return False

            if self._state in (
                FutureStatus.CANCELLED,
                FutureStatus.CANCELLED_AND_NOTIFIED,
            ):
                return True

            self._state = FutureStatus.CANCELLED
            self._condition.notify_all()

        self._invoke_callbacks()  # type: ignore[attr-defined]

        return True


class RemoteTraceback(Exception):
    """Traceback wrapper for exceptions in remote process.

    Exception.__cause__ requires a BaseException subclass.

    """

    def __init__(self, traceback):
        self.traceback = traceback

    def __str__(self):
        return self.traceback


class RemoteException:
    """Pickling wrapper for exceptions in remote process."""

    def __init__(self, exception, traceback):
        self.exception = exception
        self.traceback = traceback

    def __reduce__(self):
        return self.rebuild_exception, (self.exception, self.traceback)

    @staticmethod
    def rebuild_exception(exception, traceback):
        try:
            exception.traceback = traceback
            exception.__cause__ = RemoteTraceback(traceback)
        except AttributeError:  # Frozen exception
            pass

        return exception


class ResultStatus(IntEnum):
    """Status of results of a function execution."""

    SUCCESS = 0
    FAILURE = 1
    ERROR = 2


@dataclass
class Result(Generic[T]):
    """Result of a function execution."""

    status: ResultStatus
    value: Any


class FutureStatus(str, Enum):
    """Borrowed from concurrent.futures."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    FINISHED = "FINISHED"
    CANCELLED = "CANCELLED"
    CANCELLED_AND_NOTIFIED = "CANCELLED_AND_NOTIFIED"


@dataclass
class Consts:
    """Internal constants.

    WARNING: changing these values will affect the behaviour
    of Pools and decorators.

    """

    sleep_unit: float = 0.1
    """Any cycle which needs to periodically assess the state."""
    term_timeout: float = 3
    """On UNIX once a SIGTERM signal is issued to a process,
    the amount of seconds to wait before issuing a SIGKILL signal."""
    channel_lock_timeout: float = 60
    """The process pool relies on a pipe protected by a lock.
    The timeout when attempting to acquire the lock."""


CONSTS = Consts()
