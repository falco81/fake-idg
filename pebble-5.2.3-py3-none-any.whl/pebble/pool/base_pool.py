# This file is part of Pebble.
# Copyright (c) 2013-2026, Matteo Cafasso

# Pebble is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License
# as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.

# Pebble is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Pebble.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import annotations

import time
import logging
import itertools

from queue import Queue
from enum import IntEnum
from threading import RLock
from dataclasses import dataclass
from concurrent.futures import Future, TimeoutError
from typing import Iterator, TypeVar, Mapping
from typing import Any, Callable, Generic, Iterable

from pebble.common.types import T
from pebble.common import Result, ResultStatus, ProcessFuture, CONSTS


class BasePool:
    def __init__(
        self,
        max_workers: int,
        max_tasks: int,
        initializer: Callable | None,
        initargs: Iterable[Any],
    ):
        self._context: PoolContext = PoolContext(
            max_workers, max_tasks, initializer, initargs
        )
        self._loops: Iterable[Any] = ()
        self._task_counter: itertools.count = itertools.count()

    def __enter__(self: PoolT) -> PoolT:
        return self

    def __exit__(self, *_):
        self.close()
        self.join()

    @property
    def active(self) -> bool:
        self._update_pool_status()

        return self._context.status in (PoolStatus.CLOSED, PoolStatus.RUNNING)

    def close(self):
        """Closes the Pool preventing new tasks from being accepted.

        Pending tasks will be completed.
        """
        self._context.status = PoolStatus.CLOSED

    def stop(self):
        """Stops the pool without performing any pending task."""
        self._context.status = PoolStatus.STOPPED

    def join(self, timeout: float | None = None):
        """Joins the pool waiting until all workers exited.

        If *timeout* is set, it block until all workers are done
        or raises TimeoutError.
        """
        if self._context.status == PoolStatus.RUNNING:
            raise RuntimeError("The Pool is still running")
        if self._context.status == PoolStatus.CLOSED:
            self._wait_queue_depletion(timeout)
            self.stop()
            self.join()
        else:
            self._context.task_queue.put(None)  # Pool termination sentinel
            self._stop_pool()

    def _wait_queue_depletion(self, timeout: float | None):
        tick: float = time.time()

        while self.active:
            if timeout is not None and time.time() - tick > timeout:
                raise TimeoutError("Tasks are still being executed")
            elif self._context.task_queue.unfinished_tasks:
                time.sleep(CONSTS.sleep_unit)
            else:
                return

    def _check_pool_status(self):
        self._update_pool_status()

        if self._context.status == PoolStatus.ERROR:
            raise RuntimeError("Unexpected error within the Pool")
        elif self._context.status != PoolStatus.RUNNING:
            raise RuntimeError("The Pool is not active")

    def _update_pool_status(self):
        if self._context.status == PoolStatus.CREATED:
            self._start_pool()

        for loop in self._loops:  # type: ignore[var-annotated]
            if not loop.is_alive():
                self._context.status = PoolStatus.ERROR

    def _start_pool(self):
        raise NotImplementedError("Not implemented")

    def _stop_pool(self):
        raise NotImplementedError("Not implemented")


class PoolContext:
    def __init__(
        self,
        max_workers: int,
        max_tasks: int,
        initializer: Callable | None,
        initargs: Iterable[Any],
    ):
        self._status: PoolStatus = PoolStatus.CREATED
        self.status_mutex: RLock = RLock()

        self.task_queue: Queue[Task | None] = Queue()
        self.workers: int = max_workers
        self.task_counter: itertools.count = itertools.count()
        self.worker_parameters: Worker = Worker(max_tasks, initializer, initargs)

    @property
    def status(self) -> PoolStatus:
        return self._status

    @status.setter
    def status(self, status: PoolStatus):
        with self.status_mutex:
            if self.alive:
                self._status = status

    @property
    def alive(self) -> bool:
        return self.status not in (PoolStatus.ERROR, PoolStatus.STOPPED)


class Task:
    def __init__(
        self,
        identifier: int,
        future: Future,
        timeout: float | None,
        payload: TaskPayload,
    ):
        self.id: int = identifier
        self.future: Future = future
        self.timeout: float | None = timeout
        self.payload: TaskPayload = payload
        self.timestamp: float = 0.0
        self.worker_id: int = 0

    @property
    def started(self) -> bool:
        return bool(self.timestamp > 0)

    def set_running_or_notify_cancel(self):
        map_future: MapFuture | None = getattr(self.future, "map_future", None)
        if map_future is not None:
            if not map_future.done():
                try:
                    map_future.set_running_or_notify_cancel()
                except RuntimeError:
                    pass

        try:
            self.future.set_running_or_notify_cancel()
        except RuntimeError:
            pass


class MapFuture(Future[T]):
    def __init__(self, futures: Iterable[Future[T]]):
        super().__init__()
        self._futures: Iterable[Future[T]] = futures

    @property
    def futures(self) -> Iterable[Future[T]]:
        return self._futures

    def cancel(self) -> bool:
        """Cancel the future.

        Returns True if any of the elements of the iterables is cancelled.
        False otherwise.
        """
        super().cancel()

        return any(tuple(f.cancel() for f in self._futures))


class ProcessMapFuture(ProcessFuture[T]):
    def __init__(self, futures: Iterable[ProcessFuture[T]]):
        super().__init__()
        self._futures: Iterable[ProcessFuture[T]] = futures

    @property
    def futures(self) -> Iterable[ProcessFuture[T]]:
        return self._futures

    def cancel(self) -> bool:
        """Cancel the future.

        Returns True if any of the elements of the iterables is cancelled.
        False otherwise.
        """
        super().cancel()

        return any(tuple(f.cancel() for f in self._futures))


class MapResults(Result[T]):
    def __init__(self, futures: Iterable[Future], timeout: float | None = None):
        self._results: Iterator[Result | Exception] = itertools.chain.from_iterable(
            chunk_result(f, timeout) for f in futures
        )

    def __iter__(self) -> Iterator[T]:
        return self

    def next(self) -> T:
        result: Result | Exception = next(self._results)

        if isinstance(result, Result):
            if result.status == ResultStatus.SUCCESS:
                return result.value

            result = result.value

        raise result  # type: ignore[misc]

    __next__ = next


def map_results(map_future: MapFutureType, timeout: float | None) -> MapFutureType:
    futures: Iterable[Future] = map_future.futures
    if not futures:
        map_future.set_result(MapResults(futures))
        return map_future

    def done_map(_):
        if not map_future.done():
            map_future.set_result(MapResults(futures, timeout=timeout))

    for future in futures:
        future.add_done_callback(done_map)
        setattr(future, "map_future", map_future)

    return map_future


def iter_chunks(iterable: Iterable[Any], chunksize: int) -> Iterator:
    """Iterates over zipped iterables in chunks."""
    try:
        yield from itertools.batched(iterable, chunksize)  # type: ignore[attr-defined] - > Python 3.12
    except AttributeError:  # < Python 3.12
        while 1:
            chunk: tuple = tuple(itertools.islice(iterable, chunksize))

            if not chunk:
                return

            yield chunk


def chunk_result(future: Future[T], timeout: float | None) -> Any:
    """Returns the results of a processed chunk."""
    try:
        return future.result(timeout=timeout)
    except BaseException as error:
        return (error,)


def run_initializer(initializer: Callable, initargs: Iterable[Any]) -> bool:
    """Runs the Pool initializer dealing with errors."""
    try:
        initializer(*initargs)
        return True
    except BaseException as error:
        logging.exception(error)
        return False


class PoolStatus(IntEnum):
    """Current status of the Pool."""

    CREATED = 0
    RUNNING = 1
    CLOSED = 2
    STOPPED = 3
    ERROR = 4


@dataclass
class Worker:
    """Worker configuration."""

    max_tasks: int
    initializer: Callable | None
    initargs: Iterable[Any]


@dataclass
class TaskPayload(Generic[T]):
    """The work item wrapped within a Task."""

    function: Callable[..., T]
    args: Iterable[Any]
    kwargs: Mapping[str, Any]


PoolT = TypeVar("PoolT", bound=BasePool)
MapFutureType = TypeVar("MapFutureType", bound=MapFuture | ProcessMapFuture)
